#ifndef LETRAMORSE
#define LETRAMORSE
void letramorse (unsigned char letra);
void morseletra( char cod[]);
void apitar(unsigned char val);
#endif



