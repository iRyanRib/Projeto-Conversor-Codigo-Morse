#ifndef LEDS_H
#define	LEDS_H
void config(void);
void traco(void);
void ponto(void);
#endif

